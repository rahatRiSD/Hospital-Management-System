// This file contains the JavaScript code for client-side functionality.

// Function to fetch and display doctors
async function fetchDoctors() {
    const response = await fetch('/api/doctors');
    const doctors = await response.json();
    const doctorsList = document.getElementById('doctors-list');
    doctorsList.innerHTML = '';

    doctors.forEach(doctor => {
        const listItem = document.createElement('li');
        listItem.textContent = `${doctor.name} - ${doctor.specialty}`;
        doctorsList.appendChild(listItem);
    });
}

// Function to fetch and display patients
async function fetchPatients() {
    const response = await fetch('/api/patients');
    const patients = await response.json();
    const patientsList = document.getElementById('patients-list');
    patientsList.innerHTML = '';

    patients.forEach(patient => {
        const listItem = document.createElement('li');
        listItem.textContent = `${patient.name} - Age: ${patient.age}`;
        patientsList.appendChild(listItem);
    });
}

// Function to fetch and display appointments
async function fetchAppointments() {
    const response = await fetch('/api/appointments');
    const appointments = await response.json();
    const appointmentsList = document.getElementById('appointments-list');
    appointmentsList.innerHTML = '';

    appointments.forEach(appointment => {
        const listItem = document.createElement('li');
        listItem.textContent = `Appointment on ${appointment.date} at ${appointment.time}`;
        appointmentsList.appendChild(listItem);
    });
}

// Event listeners for document ready
document.addEventListener('DOMContentLoaded', () => {
    fetchDoctors();
    fetchPatients();
    fetchAppointments();
});