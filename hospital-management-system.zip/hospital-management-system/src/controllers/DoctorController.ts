// filepath: /hospital-management-system/hospital-management-system/src/controllers/DoctorController.ts

import { Request, Response } from 'express';

export class DoctorController {
    public getDoctors(req: Request, res: Response): void {
        // Logic to retrieve and return a list of doctors
        res.send('List of doctors');
    }

    public addDoctor(req: Request, res: Response): void {
        // Logic to add a new doctor
        res.send('Doctor added');
    }
}