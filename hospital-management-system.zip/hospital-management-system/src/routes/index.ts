import express from 'express';
import DoctorController from '../controllers/DoctorController';
import PatientController from '../controllers/PatientController';
import AppointmentController from '../controllers/AppointmentController';

const router = express.Router();

const doctorController = new DoctorController();
const patientController = new PatientController();
const appointmentController = new AppointmentController();

// Doctor routes
router.get('/doctors', doctorController.getDoctors);
router.post('/doctors', doctorController.addDoctor);

// Patient routes
router.get('/patients', patientController.getPatients);
router.post('/patients', patientController.addPatient);

// Appointment routes
router.get('/appointments', appointmentController.getAppointments);
router.post('/appointments', appointmentController.scheduleAppointment);

export default router;