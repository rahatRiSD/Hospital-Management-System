// filepath: /hospital-management-system/hospital-management-system/src/models/Appointment.ts

export class Appointment {
    date: Date;
    time: string;
    patientId: number;
    doctorId: number;

    constructor(date: Date, time: string, patientId: number, doctorId: number) {
        this.date = date;
        this.time = time;
        this.patientId = patientId;
        this.doctorId = doctorId;
    }

    // Additional methods related to appointments can be added here
}