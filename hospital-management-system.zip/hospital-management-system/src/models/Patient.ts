// filepath: /hospital-management-system/hospital-management-system/src/models/Patient.ts

export class Patient {
    private name: string;
    private age: number;
    private medicalHistory: string[];

    constructor(name: string, age: number, medicalHistory: string[]) {
        this.name = name;
        this.age = age;
        this.medicalHistory = medicalHistory;
    }

    public getName(): string {
        return this.name;
    }

    public getAge(): number {
        return this.age;
    }

    public getMedicalHistory(): string[] {
        return this.medicalHistory;
    }

    public addMedicalRecord(record: string): void {
        this.medicalHistory.push(record);
    }
}