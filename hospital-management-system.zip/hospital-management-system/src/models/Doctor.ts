// filepath: /hospital-management-system/hospital-management-system/src/models/Doctor.ts

export class Doctor {
    constructor(
        public id: number,
        public name: string,
        public specialty: string,
        public contactInfo: string
    ) {}

    getDetails() {
        return {
            id: this.id,
            name: this.name,
            specialty: this.specialty,
            contactInfo: this.contactInfo
        };
    }
}