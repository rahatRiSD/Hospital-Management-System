import express from 'express';
import bodyParser from 'body-parser';
import { DoctorController } from './controllers/DoctorController';
import { PatientController } from './controllers/PatientController';
import { AppointmentController } from './controllers/AppointmentController';
import { DatabaseService } from './services/DatabaseService';

const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Initialize Database
const databaseService = new DatabaseService();
databaseService.connect();

// Controllers
const doctorController = new DoctorController();
const patientController = new PatientController();
const appointmentController = new AppointmentController();

// Routes
app.use('/api/doctors', doctorController.router);
app.use('/api/patients', patientController.router);
app.use('/api/appointments', appointmentController.router);

// Error handling
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Something broke!');
});

// Start server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});