import { createConnection, Connection } from 'typeorm';

export class DatabaseService {
    private connection: Connection;

    constructor() {
        this.connect();
    }

    private async connect() {
        try {
            this.connection = await createConnection({
                type: 'mysql',
                host: 'localhost',
                port: 3306,
                username: 'root',
                password: 'root',
                database: 'hospital_management',
                entities: [
                    __dirname + '/../models/*.ts'
                ],
                synchronize: true,
            });
            console.log('Database connection established successfully.');
        } catch (error) {
            console.error('Database connection failed:', error);
        }
    }

    public getConnection(): Connection {
        return this.connection;
    }
}