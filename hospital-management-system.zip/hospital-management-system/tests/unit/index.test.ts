import { DoctorController } from '../../src/controllers/DoctorController';
import { PatientController } from '../../src/controllers/PatientController';
import { AppointmentController } from '../../src/controllers/AppointmentController';

describe('Hospital Management System Controllers', () => {
    let doctorController: DoctorController;
    let patientController: PatientController;
    let appointmentController: AppointmentController;

    beforeEach(() => {
        doctorController = new DoctorController();
        patientController = new PatientController();
        appointmentController = new AppointmentController();
    });

    describe('DoctorController', () => {
        it('should get doctors', async () => {
            const doctors = await doctorController.getDoctors();
            expect(doctors).toBeDefined();
        });

        it('should add a doctor', async () => {
            const doctor = { name: 'Dr. Smith', specialty: 'Cardiology' };
            const result = await doctorController.addDoctor(doctor);
            expect(result).toBeTruthy();
        });
    });

    describe('PatientController', () => {
        it('should get patients', async () => {
            const patients = await patientController.getPatients();
            expect(patients).toBeDefined();
        });

        it('should add a patient', async () => {
            const patient = { name: 'John Doe', age: 30 };
            const result = await patientController.addPatient(patient);
            expect(result).toBeTruthy();
        });
    });

    describe('AppointmentController', () => {
        it('should get appointments', async () => {
            const appointments = await appointmentController.getAppointments();
            expect(appointments).toBeDefined();
        });

        it('should schedule an appointment', async () => {
            const appointment = { date: '2023-10-01', time: '10:00', doctorId: 1, patientId: 1 };
            const result = await appointmentController.scheduleAppointment(appointment);
            expect(result).toBeTruthy();
        });
    });
});